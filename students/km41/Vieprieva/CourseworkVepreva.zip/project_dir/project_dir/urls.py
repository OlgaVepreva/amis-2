from django.conf.urls import url, include
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic import TemplateView
from authenticate.views import home

urlpatterns = [

    url(r'^admin/', admin.site.urls),

    url(r'^', include('authenticate.urls', namespace='authenticate'), name='authenticate'),

    url(r'^goods/', include('goods.urls', namespace='goods'), name='goods'),

    url(r'^adminka/', include('adminka.urls', namespace='adminka'), name='adminka'),

    url(r'^$', home, name='home'),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
