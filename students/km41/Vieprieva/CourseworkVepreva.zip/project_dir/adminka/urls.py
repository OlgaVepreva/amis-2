from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^$', views.AdminPage.as_view(), name='adminka_main'),

    url(r'^delete/(?P<pk>\d+)/$', views.DeleteProduct.as_view(), name='delete'),

    url(r'^edit/(?P<pk>\d+)/$', views.EditProduct.as_view(), name='edit'),

    url(r'^add_money/(?P<pk>\d+)/$', views.UsersMoney.as_view(), name='add_money'),

    url(r'^add_money/$', views.UsersMoney.as_view(), name='add_money_view'),

    url(r'^orders/$', views.AdminOrders.as_view(), name='admin_orders'),

    url(r'^orders/(?P<pk>\d+)/$', views.AdminOrders.as_view(), name='admin_orders_post'),

]
