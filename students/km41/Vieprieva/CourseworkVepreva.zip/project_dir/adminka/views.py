from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from goods.models import Goods
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import transaction
from django.db import connection
from django.core.files.storage import FileSystemStorage

from authenticate.models import User
from goods.models import Order
from .forms import GoodsForm


@method_decorator(login_required, name='dispatch')
class AdminPage(View):
    template_name = 'adminka/adminka.html'

    def get(self, request):
        goods = Goods.objects.all()
        form = GoodsForm()
        return render(request, self.template_name, {'form': form, 'goods': goods})

    def post(self, request):
        form = GoodsForm(request.POST, request.FILES)
        if form.is_valid():

            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price = int(request.POST.get('price'))
            weight = request.POST.get('weight')
            if weight:
                weight = int(weight)
            vendor = request.POST.get('vendor')
            category = request.POST.get('category') or ''
            quantity = int(request.POST.get('quantity'))
            goods_pic = request.FILES.get('goods_pic')

            if not goods_pic:
                goods_pic = 'goods/no_goods.jpg'
            else:
                myfile = request.FILES.get('goods_pic')
                fs = FileSystemStorage()
                goods_pic = 'goods/' + goods_pic.name
                filename = fs.save(goods_pic, myfile)

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('MANAGE_GOODS_PACKAGE.ADD_GOODS', [
                    name, 
                    description, 
                    price,
                    weight,
                    vendor,
                    category,
                    quantity,
                    goods_pic])

            # form.save()
            return redirect(reverse('adminka:adminka_main'))
        return render(request, self.template_name, {'form':form})


@method_decorator(login_required, name='dispatch')
class DeleteProduct(View):
    template_name = 'adminka/adminka.html'

    def post(self, request, pk):
        # Goods.objects.get(pk=pk).delete()
        with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('MANAGE_GOODS_PACKAGE.DELETE_GOODS', [pk])
        return redirect(reverse('adminka:adminka_main'))


@method_decorator(login_required, name='dispatch')
class EditProduct(View):
    template_name = 'adminka/edit.html'

    def get(self, request, pk):
        goods = Goods.objects.get(pk=pk)
        form = GoodsForm(instance=goods)
        return render(request, self.template_name, {'form': form, 'goods': goods})

    def post(self, request, pk):
        goods = Goods.objects.get(pk=pk)
        form = GoodsForm(request.POST, request.FILES, instance=goods)
        if form.is_valid():

            name = request.POST.get('name')
            description = request.POST.get('description') or ''
            price = int(request.POST.get('price'))
            weight = request.POST.get('weight')
            if weight:
                weight = int(weight)
            vendor = request.POST.get('vendor')
            category = request.POST.get('category') or ''
            quantity = int(request.POST.get('quantity'))
            goods_pic = request.FILES.get('goods_pic')

            if not goods_pic:
                goods_pic = 'goods/no_goods.jpg'
            else:
                myfile = request.FILES.get('goods_pic')
                fs = FileSystemStorage()
                filename = fs.save(goods_pic, myfile)
                goods_pic = 'goods/' + goods_pic.name

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                cursor.callproc('MANAGE_GOODS_PACKAGE.CHANGE_GOODS', [
                    pk,
                    name, 
                    description, 
                    price,
                    weight,
                    vendor,
                    category,
                    quantity,
                    goods_pic])

            # form.save()
            return redirect(reverse('adminka:adminka_main'))
        return render(request, self.template_name, {'form':form})



@method_decorator(login_required, name='dispatch')
class UsersMoney(View):
    template_name = 'adminka/add_money.html'

    def get(self, request):
        users = User.objects.all()
        return render(request, self.template_name, {'users': users})

    def post(self, request, pk):
        money = int(request.POST.get('money'))
        user = User.objects.raw("SELECT * FROM AUTHENTICATE_USER WHERE ID={}".format(pk))[0]
        
        with transaction.atomic():
            cursor = connection.cursor()
            cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

            cursor.callproc('PACKAGE_SEND_MONEY.SEND', [user.id, money])

        return redirect(reverse('adminka:add_money_view'))


@method_decorator(login_required, name='dispatch')
class AdminOrders(View):
    template_name = 'adminka/orders.html'

    def get(self, request):
        orders = Order.objects.filter(is_confirmed=False)

        return render(request, self.template_name, {'orders': orders})

    def post(self, request, pk):

        order = Order.objects.get(pk=pk)
        profile = User.objects.get(pk=order.user.id)
        goods = Goods.objects.get(pk=order.goods.id)

        to_pay = order.quantity * goods.price

        profile.balance -= to_pay
        profile.save()
        goods.quantity -= order.quantity
        goods.save()
        order.is_confirmed = True
        order.save()

        return redirect(reverse('adminka:admin_orders'))
