from goods.models import Goods
from django import forms
from django.forms.widgets import PasswordInput, NumberInput


class GoodsForm(forms.ModelForm):
    name = forms.CharField(max_length=35, help_text='name')
    description = forms.CharField(max_length=35, required=False, help_text='description')
    price = forms.IntegerField(help_text='price', widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    weight = forms.IntegerField(required=False, help_text='price', widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    vendor = forms.CharField(max_length=35, required=False, help_text='vendor')
    category = forms.CharField(max_length=35, required=False, help_text='category')
    quantity = forms.IntegerField(help_text='quantity', widget=NumberInput(attrs={'class':'validate', 'min':"1", 'max': "100"}))
    goods_pic = forms.ImageField(required=False, help_text='goods_pic')

    class Meta:
        model = Goods
        fields = '__all__'

