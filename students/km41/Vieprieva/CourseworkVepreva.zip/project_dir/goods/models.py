from django.db import models
from django.conf import settings

class Goods(models.Model):
    name = models.CharField(
        max_length=40,
        default='Default name',
    )
    description = models.CharField(
        max_length=200,
        blank=True,
        null=True,
    )
    price = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=0,
    )
    weight = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=0,
    )
    vendor = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        default='Nobrend',
    )
    category = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        default='Default category',
    )
    quantity = models.PositiveIntegerField(
        default=1,
    )
    goods_pic = models.ImageField(
        upload_to='goods/',
        blank=True,
        default='goods/no_goods.jpg',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Goods"
        verbose_name_plural = "Goods"


class Order(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    goods = models.ForeignKey(
        'Goods',
        verbose_name='Goods',
        on_delete=models.SET_NULL,
        null=True,
    )
    quantity = models.PositiveIntegerField(
        default=1,
    )
    is_confirmed = models.NullBooleanField(default=False)
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )

    def __str__(self):
        return 'Order on {}'.format(self.create_time)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"


