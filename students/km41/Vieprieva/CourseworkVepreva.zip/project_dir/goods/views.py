from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.views import View
from authenticate.models import User
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import transaction
from django.db import connection

from .models import Goods, Order


class All_Goods(View):
    template_name = 'goods/all_goods.html'

    def get(self, request):
        goods = Goods.objects.all()
        return render(request, self.template_name, {'goods':goods})


@method_decorator(login_required, name='dispatch')
class GoodsDetails(View):
    template_name = 'goods/details.html'

    def get(self, request, pk):
        goods = Goods.objects.get(pk=pk)
        return render(request, self.template_name, {'goods':goods})

    def post(self, request, pk):
        quantity = int(request.POST.get('quantity'))
        user = request.user
        _get_id = ''
        profile = User.objects.get(pk=user.id)
        goods = Goods.objects.get(pk=pk)
        # goods.quantity -= quantity
        # goods.save()

        to_pay = quantity * goods.price
        if profile.balance >= to_pay:
            # profile.balance -= to_pay
            # profile.save()

            with transaction.atomic():
                cursor = connection.cursor()
                cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                get_id = int(cursor.callproc('ORDER_GOODS.CREATE_PROCEDURE', [
                    user.id,
                    goods.id,
                    quantity,
                    _get_id])[-1])

                # order = Order.objects.create(user_id=user.id, goods_id=pk, quantity=quantity)
                return redirect(reverse('goods:orders_pk', args=(get_id,)))

        else:
            return render(request, self.template_name, {'goods': goods, 'fail': True, 'quantity': quantity, 'to_pay': to_pay, 'balance': profile.balance})


@method_decorator(login_required, name='dispatch')
class Orders(View):
    template_name = 'goods/one_order.html'

    def get(self, request, pk):
        
        cursor = connection.cursor()
        cursor.execute('SELECT "USER_ID",\
                            "GOODS_QUANTITY",\
                            "GOODS_ID",\
                            "CREATE_TIME",\
                            "USERNAME",\
                            "GOODS_NAME"\
            FROM "MY_ORDER_VIEW" \
            WHERE "ORDER_ID" = {id}'.format(id=pk))

        USER_ID, GOODS_QUANTITY, GOODS_ID, CREATE_TIME, USERNAME, GOODS_NAME = cursor.fetchone()

        context = {
            "USER_ID":USER_ID,
            "GOODS_QUANTITY":GOODS_QUANTITY,
            "GOODS_ID":GOODS_ID,
            "CREATE_TIME":CREATE_TIME,
            "USERNAME":USERNAME,
            "GOODS_NAME": GOODS_NAME,
        }
        # order = Order.objects.get(pk=pk)
        return render(request, self.template_name, context)


@method_decorator(login_required, name='dispatch')
class UserOrders(View):
    template_name = 'goods/orders.html'

    def get(self, request, pk=None):
        is_own = False
        if not pk:
            pk = request.user.id
        user = User.objects.get(pk=pk)

        if user.id == request.user.id:
            is_own = True

        orders = Order.objects.filter(user_id=pk)
        import ipdb; ipdb.set_trace()
        return render(request, self.template_name, {'is_own': is_own, 'user': user, 'orders': orders})

