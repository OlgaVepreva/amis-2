from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^goods/$', views.All_Goods.as_view(), name='goods'),

    url(r'^details/(?P<pk>\d+)/$', views.GoodsDetails.as_view(), name='details'),

    url(r'^orders/$', views.Orders.as_view(), name='orders'),
    url(r'^orders/(?P<pk>\d+)/$', views.Orders.as_view(), name='orders_pk'),

    url(r'^user_order/$', views.UserOrders.as_view(), name='user'),
    url(r'^user_order/(?P<pk>\d+)/$', views.UserOrders.as_view(), name='user_pk'),

    # url(r'^profile/(?P<pk>\d+)/$', views.Profile.as_view(), name='profile_with_pk'),

    # url(r'^order_details/(?P<pk>\d+)/$', views.OrderDetails.as_view(), name='order_details'),

]
