from django.shortcuts import render, redirect
from .forms import UserForm
from django.core.urlresolvers import reverse
from django.contrib.auth import login, authenticate

def signup(request):
    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/')
    else:
        form = UserForm()
    return render(request, 'registration/signup.html', {'form': form})


def home(request):
    return render(request, 'home.html')
