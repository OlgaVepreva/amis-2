from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin

from .models import User


class UserAdmin(DefaultUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('User info', {'fields': ('username', 'first_name', 'last_name', 'email', 'avatar',
        	# 'phone', 'adress', 'shop_name',
        	'is_active', 'is_superuser', 'is_staff',)}),
    )    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'avatar',
            	# 'phone', 'adress', 'shop_name',
            	'is_active', 'is_superuser', 'is_staff')}
        ),
    )


admin.site.register(User, UserAdmin)
