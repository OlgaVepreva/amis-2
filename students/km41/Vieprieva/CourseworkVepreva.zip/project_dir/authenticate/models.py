from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings


class User(AbstractUser):
    avatar = models.ImageField(
        upload_to='avatars/',
        blank=True,
        default='avatars/no_profile.jpg',
        verbose_name='File'
    )
    balance = models.PositiveIntegerField(
        null=True,
        blank=True,
        default=1000,
    )

    class Meta(object):
        unique_together = ('email',)
